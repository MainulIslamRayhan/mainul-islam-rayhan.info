import React from 'react';
import { Facebook, Instagram, Youtube } from 'lucide-react';

export default function Footer() {
  const year = new Date().getFullYear();
  
  return (
    <footer className="py-12 bg-secondary/50 border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <h2 className="text-2xl md:text-3xl font-display font-bold text-primary mb-6">MAINUL ISLAM RAYHAN</h2>
        
        <div className="flex justify-center space-x-6 mb-8">
          <a href="https://www.facebook.com/share/1Dg8xWuXCW/" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-primary transition-colors">
            <Facebook size={20} />
          </a>
          <a href="https://www.instagram.com/mainulislamrayhan_?igsh=bzZ6ZTJwZXZhYXRm" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-primary transition-colors">
            <Instagram size={20} />
          </a>
          <a href="https://youtube.com/@mahfell?si=qtTox5kXIf8ddGpm" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-primary transition-colors">
            <Youtube size={20} />
          </a>
        </div>

        <div className="flex justify-center space-x-8 mb-8">
          <a href="#home" className="text-sm uppercase tracking-widest text-slate-500 hover:text-primary transition-colors">Home</a>
          <a href="#about" className="text-sm uppercase tracking-widest text-slate-500 hover:text-primary transition-colors">About</a>
          <a href="#portfolio" className="text-sm uppercase tracking-widest text-slate-500 hover:text-primary transition-colors">Portfolio</a>
          <a href="#contact" className="text-sm uppercase tracking-widest text-slate-500 hover:text-primary transition-colors">Contact</a>
        </div>
        <p className="text-slate-400 text-sm">
          &copy; {year} Mainul Islam Rayhan. All Rights Reserved.
        </p>
      </div>
    </footer>
  );
}

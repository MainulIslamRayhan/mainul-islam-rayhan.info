import React from 'react';
import { motion } from 'motion/react';
import { ExternalLink, PlayCircle, Camera, Layout } from 'lucide-react';

const projects = [
  {
    title: 'Rickshaw Art of Dhaka',
    category: 'Documentary',
    icon: Camera,
    img: 'https://images.unsplash.com/photo-1621847468516-1ed5d0df56fe?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Sundarbans Mangrove Forest',
    category: 'Nature',
    icon: Camera,
    img: 'https://images.unsplash.com/photo-1589908000350-18828d2461d1?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Sylhet Tea Gardens',
    category: 'Landscape',
    icon: Camera,
    img: 'https://images.unsplash.com/photo-1590490359854-dfba19688d70?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Old Dhaka Streets',
    category: 'Street Photography',
    icon: Camera,
    img: 'https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Cox\'s Bazar Sunset',
    category: 'Landscape',
    icon: Camera,
    img: 'https://images.unsplash.com/photo-1582650625119-3a31f8fa2699?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Rural Life in Bangladesh',
    category: 'Documentary',
    icon: Camera,
    img: 'https://images.unsplash.com/photo-1600132806370-bf17e65e942f?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Sajek Valley Clouds',
    category: 'Landscape',
    icon: Camera,
    img: 'https://images.unsplash.com/photo-1623945359620-309489679198?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Fishing in the Padma',
    category: 'Documentary',
    icon: Camera,
    img: 'https://images.unsplash.com/photo-1599059813005-11265ba4b4ce?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Baitul Mukarram Mosque',
    category: 'Architecture',
    icon: Camera,
    img: 'https://images.unsplash.com/photo-1623057000739-386c80bb71f7?auto=format&fit=crop&w=800&q=80',
  },
];

export default function Portfolio() {
  return (
    <section id="portfolio" className="section-padding bg-secondary/30">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div>
            <span className="text-accent font-bold tracking-widest uppercase text-sm mb-4 block">My Recent Works</span>
            <h2 className="text-4xl md:text-5xl font-display">Featured Projects</h2>
          </div>
          <p className="max-w-md text-slate-500 italic font-serif">
            A selection of my best work across video editing, photography, and creative design.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, i) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative overflow-hidden rounded-3xl bg-white shadow-sm"
            >
              <div className="aspect-[16/10] overflow-hidden">
                <img
                  src={project.img}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-8">
                <div className="flex items-center gap-2 text-white/70 text-sm mb-2">
                  <project.icon size={16} />
                  <span>{project.category}</span>
                </div>
                <h3 className="text-2xl font-display text-white mb-4">{project.title}</h3>
                <a
                  href="#"
                  className="inline-flex items-center gap-2 text-white font-medium hover:text-accent transition-colors"
                >
                  View Project <ExternalLink size={16} />
                </a>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-10 py-4 border-2 border-primary text-primary rounded-full font-bold hover:bg-primary hover:text-white transition-all"
          >
            Explore All Projects
          </motion.button>
        </div>
      </div>
    </section>
  );
}

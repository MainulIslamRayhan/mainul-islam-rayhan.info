import React from 'react';
import { motion } from 'motion/react';
import { Video, Palette, Camera, BookOpen, Share2 } from 'lucide-react';

const skills = [
  { name: 'Video Editing', icon: Video, desc: 'DaVinci Resolve, Premiere Pro', color: 'bg-blue-50 text-blue-600' },
  { name: 'Graphic Design', icon: Palette, desc: 'Thumbnails, Posters, Branding', color: 'bg-purple-50 text-purple-600' },
  { name: 'Photography', icon: Camera, desc: 'Professional Shoots & Editing', color: 'bg-orange-50 text-orange-600' },
  { name: 'Islamic Content', icon: BookOpen, desc: 'Research & Script Writing', color: 'bg-emerald-50 text-emerald-600' },
  { name: 'Social Media', icon: Share2, desc: 'Content Strategy & Creation', color: 'bg-pink-50 text-pink-600' },
];

export default function Skills() {
  return (
    <section id="skills" className="section-padding bg-secondary/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-accent font-bold tracking-widest uppercase text-sm mb-4 block">Expertise</span>
          <h2 className="text-4xl md:text-5xl font-display">My Creative Skills</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
          {skills.map((skill, i) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -5 }}
              className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center text-center"
            >
              <div className={`w-16 h-16 rounded-2xl ${skill.color} flex items-center justify-center mb-6`}>
                <skill.icon size={32} />
              </div>
              <h3 className="text-xl font-display mb-2">{skill.name}</h3>
              <p className="text-sm text-slate-500">{skill.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

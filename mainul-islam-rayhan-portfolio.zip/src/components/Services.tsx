import React from 'react';
import { motion } from 'motion/react';
import { Camera, Video, Film, Scissors, Palette, Smartphone } from 'lucide-react';

const services = [
  {
    title: 'Photography',
    desc: 'Capturing powerful moments through creative composition and storytelling. From portraits to documentary and street photography — every frame tells a story.',
    icon: <Camera size={32} />,
  },
  {
    title: 'Videography',
    desc: 'Professional video production including cinematic shoots, event coverage, and storytelling-based content creation.',
    icon: <Video size={32} />,
  },
  {
    title: 'Documentary Filmmaking',
    desc: 'Creating meaningful documentaries that highlight real stories, culture, and human experiences with a cinematic approach.',
    icon: <Film size={32} />,
  },
  {
    title: 'Video Editing',
    desc: 'High-quality editing using tools like DaVinci Resolve and Premiere Pro — including color grading, transitions, and storytelling cuts.',
    icon: <Scissors size={32} />,
  },
  {
    title: 'Graphic Design',
    desc: 'Creative design solutions including YouTube thumbnails, posters, and social media content that stand out visually.',
    icon: <Palette size={32} />,
  },
  {
    title: 'Social Media Content',
    desc: 'Engaging content creation tailored for platforms like YouTube, Facebook, and Instagram to grow audience and impact.',
    icon: <Smartphone size={32} />,
  },
];

export default function Services() {
  return (
    <section id="services" className="section-padding bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-accent font-bold tracking-widest uppercase text-sm mb-4 block"
          >
            What I Offer
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-display mb-6"
          >
            Services I Offer
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-lg text-slate-600 max-w-2xl mx-auto"
          >
            Creative solutions tailored to bring your vision to life.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -10 }}
              className="group p-8 rounded-3xl border border-slate-100 bg-secondary/30 hover:bg-white hover:shadow-2xl hover:shadow-primary/5 transition-all duration-500"
            >
              <div className="w-16 h-16 rounded-2xl bg-primary/5 text-primary flex items-center justify-center mb-8 group-hover:bg-primary group-hover:text-white transition-colors duration-500">
                {service.icon}
              </div>
              <h3 className="text-2xl font-display mb-4 group-hover:text-primary transition-colors">
                {service.title}
              </h3>
              <p className="text-slate-500 leading-relaxed">
                {service.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

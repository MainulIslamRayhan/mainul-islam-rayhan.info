import React from 'react';
import { motion } from 'motion/react';

const experiences = [
  {
    role: 'Founder',
    company: 'Mahfel (Islamic Content Platform)',
    period: '2022 - Present',
    desc: 'Leading a platform dedicated to high-quality Islamic media production and educational content.',
  },
  {
    role: 'Freelance Video Editor',
    company: 'Global Clients',
    period: '2020 - Present',
    desc: 'Providing professional video editing services for YouTube channels, businesses, and individual creators.',
  },
  {
    role: 'Creative Consultant',
    company: 'Various Projects',
    period: '2021 - 2023',
    desc: 'Assisting in social media strategy and content creation for multiple creative platforms.',
  },
];

export default function Experience() {
  return (
    <section className="section-padding bg-white">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-accent font-bold tracking-widest uppercase text-sm mb-4 block">Journey</span>
          <h2 className="text-4xl md:text-5xl font-display">Work Experience</h2>
        </div>

        <div className="space-y-12">
          {experiences.map((exp, i) => (
            <motion.div
              key={exp.company}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="relative pl-8 md:pl-0"
            >
              <div className="md:grid md:grid-cols-12 gap-8">
                <div className="md:col-span-4 mb-2 md:mb-0">
                  <span className="text-accent font-bold block">{exp.period}</span>
                  <h4 className="text-xl font-display text-primary">{exp.company}</h4>
                </div>
                <div className="md:col-span-8 relative">
                  {/* Timeline Line */}
                  <div className="hidden md:block absolute -left-4 top-0 bottom-0 w-[1px] bg-slate-100" />
                  <div className="hidden md:block absolute -left-[19px] top-2 w-2.5 h-2.5 rounded-full bg-primary" />
                  
                  <h3 className="text-2xl font-display mb-3">{exp.role}</h3>
                  <p className="text-slate-500 leading-relaxed">{exp.desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

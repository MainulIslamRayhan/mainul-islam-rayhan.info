import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Play } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Cinematic Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://picsum.photos/seed/cinematic/1920/1080?blur=2"
          alt="Cinematic Background"
          className="w-full h-full object-cover scale-105"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60" />
      </div>

      <div className="container mx-auto px-6 relative z-10 text-center text-white">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <motion.a
            href="https://www.pexels.com/@mainul-islam-rayhan-1108939958/"
            target="_blank"
            rel="noopener noreferrer"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="hero-name inline-block px-6 py-2 mb-8 text-sm font-medium tracking-[0.3em] uppercase border border-white/20 rounded-full backdrop-blur-sm cursor-pointer"
          >
            Mainul Islam Rayhan
          </motion.a>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-light leading-tight mb-4">
            Photographer <span className="text-white/40">|</span> Videographer <br className="hidden md:block" />
            <span className="italic font-serif">Documentary Filmmaker</span>
          </h1>

          <p className="max-w-3xl mx-auto text-lg md:text-xl text-white/80 mb-12 font-serif italic tracking-wide leading-relaxed">
            "Capturing real stories through visuals — blending creativity, emotion, and purpose into every frame."
          </p>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="max-w-2xl mx-auto mb-12 text-sm md:text-base text-white/60 font-light leading-relaxed"
          >
            I create powerful visual experiences through photography, filmmaking, and design. 
            From documentaries to creative content, my work focuses on storytelling that connects, inspires, and leaves an impact.
          </motion.div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <motion.a
              href="#portfolio"
              whileHover={{ scale: 1.05, backgroundColor: "rgba(255,255,255,1)", color: "#000" }}
              whileTap={{ scale: 0.95 }}
              className="w-full sm:w-auto px-10 py-4 bg-white/10 backdrop-blur-md text-white border border-white/30 rounded-full font-medium flex items-center justify-center gap-2 transition-all"
            >
              View My Work <Play size={16} fill="currentColor" />
            </motion.a>
            <motion.a
              href="#contact"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-full sm:w-auto px-10 py-4 bg-primary text-white rounded-full font-medium flex items-center justify-center gap-2 shadow-2xl shadow-primary/40 hover:bg-primary/90 transition-all"
            >
              Hire Me <ArrowRight size={18} />
            </motion.a>
          </div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
            className="mt-20 pt-10 border-t border-white/10"
          >
            <p className="text-xs md:text-sm tracking-[0.4em] uppercase text-white/40 font-medium">
              Every frame tells a story. Every story carries a meaning.
            </p>
            <p className="mt-4 text-sm md:text-base text-accent font-serif italic">
              Visual storytelling with purpose — capturing life, culture, and meaningful moments.
            </p>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/30"
      >
        <div className="w-[1px] h-16 bg-gradient-to-b from-white/50 to-transparent mx-auto" />
      </motion.div>
    </section>
  );
}

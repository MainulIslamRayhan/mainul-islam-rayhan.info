import React from 'react';
import { motion } from 'motion/react';
import { Mail, Facebook, Youtube, Send, MessageCircle, Instagram, ArrowRight } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="section-padding bg-slate-900 text-white overflow-hidden relative">
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-primary blur-[120px]" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[400px] h-[400px] rounded-full bg-accent blur-[100px]" />
      </div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-32 items-start">
          <div>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="text-primary font-bold tracking-[0.2em] uppercase text-xs mb-6 block">Available for projects</span>
              <h2 className="text-5xl md:text-7xl font-display mb-8 leading-[0.9] tracking-tighter">
                Let's build <br /> something <br /> <span className="text-primary italic">extraordinary.</span>
              </h2>
              <p className="text-xl text-slate-400 mb-12 max-w-md leading-relaxed">
                Have a vision? I have the tools to bring it to life. Reach out and let's start the conversation.
              </p>
            </motion.div>

            <div className="space-y-10">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="flex flex-col space-y-6"
              >
                <a href="mailto:mdmainulislamrayhan@gmail.com" className="group flex items-center gap-4 text-2xl font-display hover:text-primary transition-colors">
                  mdmainulislamrayhan@gmail.com
                  <ArrowRight className="opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                </a>
                
                <div className="flex flex-wrap gap-8">
                  <a href="https://wa.me/8801852486965" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
                    <MessageCircle size={18} className="text-primary" />
                    <span>WhatsApp</span>
                  </a>
                  <a href="https://t.me/+8801852486965" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
                    <Send size={18} className="text-primary" />
                    <span>Telegram</span>
                  </a>
                </div>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="pt-8 border-t border-white/10"
              >
                <p className="text-xs uppercase tracking-widest text-slate-500 mb-6 font-bold">Follow My Journey</p>
                <div className="flex gap-6">
                  {[
                    { icon: Facebook, href: "https://www.facebook.com/share/1Dg8xWuXCW/" },
                    { icon: Instagram, href: "https://www.instagram.com/mainulislamrayhan_?igsh=bzZ6ZTJwZXZhYXRm" },
                    { icon: Youtube, href: "https://youtube.com/@mahfell?si=qtTox5kXIf8ddGpm" }
                  ].map((social, i) => (
                    <a 
                      key={i}
                      href={social.href} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center hover:bg-primary hover:border-primary hover:scale-110 transition-all duration-300"
                    >
                      <social.icon size={20} />
                    </a>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-white/5 backdrop-blur-xl p-8 md:p-12 rounded-[2rem] border border-white/10 shadow-2xl relative overflow-hidden group"
          >
            <div className="absolute top-0 left-0 w-1 h-full bg-primary scale-y-0 group-hover:scale-y-100 transition-transform duration-500 origin-top" />
            
            <h3 className="text-3xl font-display mb-10">Send a Message</h3>
            <form className="space-y-8" onSubmit={(e) => e.preventDefault()}>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="relative">
                  <input
                    type="text"
                    id="name"
                    className="peer w-full bg-transparent border-b border-white/20 py-2 focus:border-primary outline-none transition-colors placeholder-transparent"
                    placeholder="Name"
                  />
                  <label htmlFor="name" className="absolute left-0 -top-3.5 text-slate-500 text-xs uppercase tracking-widest font-bold transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-2 peer-focus:-top-3.5 peer-focus:text-primary peer-focus:text-xs">
                    Full Name
                  </label>
                </div>
                <div className="relative">
                  <input
                    type="email"
                    id="email"
                    className="peer w-full bg-transparent border-b border-white/20 py-2 focus:border-primary outline-none transition-colors placeholder-transparent"
                    placeholder="Email"
                  />
                  <label htmlFor="email" className="absolute left-0 -top-3.5 text-slate-500 text-xs uppercase tracking-widest font-bold transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-2 peer-focus:-top-3.5 peer-focus:text-primary peer-focus:text-xs">
                    Email Address
                  </label>
                </div>
              </div>
              
              <div className="relative">
                <input
                  type="text"
                  id="subject"
                  className="peer w-full bg-transparent border-b border-white/20 py-2 focus:border-primary outline-none transition-colors placeholder-transparent"
                  placeholder="Subject"
                />
                <label htmlFor="subject" className="absolute left-0 -top-3.5 text-slate-500 text-xs uppercase tracking-widest font-bold transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-2 peer-focus:-top-3.5 peer-focus:text-primary peer-focus:text-xs">
                  Subject
                </label>
              </div>

              <div className="relative">
                <textarea
                  id="message"
                  rows={4}
                  className="peer w-full bg-transparent border-b border-white/20 py-2 focus:border-primary outline-none transition-colors placeholder-transparent resize-none"
                  placeholder="Message"
                />
                <label htmlFor="message" className="absolute left-0 -top-3.5 text-slate-500 text-xs uppercase tracking-widest font-bold transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-2 peer-focus:-top-3.5 peer-focus:text-primary peer-focus:text-xs">
                  Your Message
                </label>
              </div>

              <button className="w-full py-5 bg-primary text-white rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/20 transition-all group/btn">
                Send Inquiry 
                <Send size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

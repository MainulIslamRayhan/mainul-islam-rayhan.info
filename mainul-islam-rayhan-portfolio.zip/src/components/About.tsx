import React from 'react';
import { motion } from 'motion/react';

export default function About() {
  return (
    <section id="about" className="section-padding bg-white">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <span className="text-accent font-bold tracking-widest uppercase text-sm mb-4 block">About Me</span>
          <h2 className="text-4xl md:text-5xl font-display mb-8 leading-tight">
            Mainul Islam Rayhan
          </h2>
          <div className="space-y-6 text-lg text-slate-600 leading-relaxed max-w-3xl mx-auto">
            <p>
              Mainul Islam Rayhan is a <span className="text-primary font-semibold">Photographer, Videographer, Documentary Filmmaker</span>, and <span className="text-primary font-semibold">Creative Designer</span> based in Bangladesh. He specializes in visual storytelling through photography, cinematic video production, and documentary filmmaking.
            </p>
            <p>
              He works across multiple creative fields including video editing and graphic design, delivering visually compelling and meaningful content. His work focuses on capturing real-life stories, emotions, and moments that connect deeply with people.
            </p>
            <p>
              Alongside his creative journey, he is also involved in producing Islamic content, combining creativity with purpose to create impactful media.
            </p>
          </div>

          <div className="mt-16 grid md:grid-cols-2 gap-8 text-left">
            <div className="p-8 bg-secondary/50 rounded-3xl border-l-4 border-accent shadow-sm">
              <h4 className="text-sm font-bold uppercase tracking-widest text-accent mb-4">Personal Journey</h4>
              <p className="text-slate-600 italic font-serif leading-relaxed text-lg">
                "I have always been passionate about capturing real moments and turning them into powerful visual stories. From photography to filmmaking, every step of my journey has been driven by curiosity and creativity."
              </p>
            </div>

            <div className="p-8 bg-primary/5 rounded-3xl border-l-4 border-primary shadow-sm">
              <h4 className="text-sm font-bold uppercase tracking-widest text-primary mb-4">Creative Vision</h4>
              <p className="text-slate-600 italic font-serif leading-relaxed text-lg">
                "I believe visual storytelling is one of the most powerful ways to communicate. My vision is to build a creative identity where storytelling meets authenticity."
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
